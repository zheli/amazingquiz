jQuery(document).ready(function(){
 
 $.localScroll({
 	offset : { top: -130 }
  }); 
});
