=== ecqlipse 2 (.PNG) by chrfb ===

The packet contains 116 system and 165 application PNG's in white respectively black colour.
Icon size: 128x128 plus a separate folder including 48x48, 32x32 and 16x16 pixel.

Please refer to the Creative Commons (CC) on my site if you want to use or modify the icons.

http://chrfb.deviantart.com

Munich, 2010/03



